import { Box, Container, Grid, Typography, colors, makeStyles } from '@mui/material'
// import { makeStyles } from ' @mui/styles'
import React from 'react'

export default function Home() {
    const imageStyle = {
        maxWidth: '50%',
        maxHeight: '50%', display: "block",
        marginLeft: "auto",
        marginRight: "auto",
        width: "50 %"
    };

    return <Container>


        <Box
            style={{
                padding: "10px",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                color: "white",
                backgroundColor: '#2B2B2B',
            }}
        >
            <Typography variant="h4" sx={{ margin: "20px" }} >Our Key Value</Typography>
            <Grid
                container
                spacing={5}
                style={{
                    padding: "60px",
                    display: "flex",
                    alignItems: "center",
                    color: 'white'
                }}
            >

                {/* ////////////////////////////////////////// */}
                <Grid
                    item
                    xs={12}
                    sm={6}
                    md={4}
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        textAlign: "center",
                        // alignItems: "center",
                    }}
                >
                    <img src="images/Group 1558.png
                    " alt="Image" style={imageStyle} />
                    <Typography variant="h5" color="initial" sx={{ color: '#FFFFFF', marginTop: "10px" }}>
                        Get notice by right customer
                    </Typography>
                    <Typography sx={{ color: '#FFFFFF', paddingX: "47px", marginTop: "10px" }} >Lorem ipsum dolor sit amet consectetur adipisicings ducimus dolorum, sed id maxime provmque modi beatae sed consectetur quisquam ullam dicta dolorum maiores</Typography>
                </Grid>
                <Grid
                    item
                    xs={12}
                    sm={6}
                    md={4}
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        textAlign: "center",
                        // alignItems: "center",
                    }}
                >
                    <img src="images/call.png
                    " alt="Image" style={imageStyle} />
                    <Typography variant="h5" color="initial" sx={{ color: '#FFFFFF', marginTop: "10px" }}>
                        Get notice by right customer
                    </Typography>
                    <Typography sx={{ color: '#FFFFFF', paddingX: "47px", marginTop: "10px" }} >Lorem ipsum dolor sit amet consectetur adipisicings ducimus dolorum, sed id maxime provmque modi beatae sed consectetur quisquam ullam dicta dolorum maiores</Typography>
                </Grid>
                <Grid
                    item
                    xs={12}
                    sm={6}
                    md={4}
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        textAlign: "center",
                        // alignItems: "center",
                    }}
                >
                    <img src="images/Group 1551.png
                    " alt="Image" style={imageStyle} />
                    <Typography variant="h5" color="initial" sx={{ color: '#FFFFFF', marginTop: "10px" }}>
                        Get notice by right customer
                    </Typography>
                    <Typography sx={{ color: '#FFFFFF', paddingX: "47px", marginTop: "10px" }} >Lorem ipsum dolor sit amet consectetur adipisicings ducimus dolorum, sed id maxime provmque modi beatae sed consectetur quisquam ullam dicta dolorum maiores</Typography>
                </Grid>
            </Grid>
            <Grid
                container
                spacing={5}
                style={{
                    padding: "50px",
                    display: "flex",
                    alignItems: "center",
                    // backgroundColor: '#2B2B2B',
                    color: 'white'
                }}
            >

                {/* ////////////////////////////////////////// */}
                <Grid
                    item
                    xs={12}
                    sm={6}
                    md={4}
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        textAlign: "center",
                        // paddingX: "50px"
                        // alignItems: "center",
                    }}
                >
                    <img src="images/Group 1554.png
                    " alt="Image" style={imageStyle} />
                    <Typography variant="h5" color="initial" sx={{ color: '#FFFFFF', marginTop: "10px" }}>
                        Get notice by right customer
                    </Typography>
                    <Typography sx={{ color: '#FFFFFF', paddingX: "47px", marginTop: "10px" }} >Lorem ipsum dolor sit amet consectetur adipisicings ducimus dolorum, sed id maxime provmque modi beatae sed consectetur quisquam ullam dicta dolorum maiores</Typography>
                </Grid>
                <Grid
                    item
                    xs={12}
                    sm={6}
                    md={4}
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        textAlign: "center",
                        // alignItems: "center",
                    }}
                >
                    <img src="images/Vector.png
                    " alt="Image" style={imageStyle} />
                    <Typography variant="h5" color="initial" sx={{ color: '#FFFFFF', marginTop: "10px" }}>
                        Get notice by right customer
                    </Typography>
                    <Typography sx={{ color: '#FFFFFF', paddingX: "47px", marginTop: "10px" }} >Lorem ipsum dolor sit amet consectetur adipisicings ducimus dolorum, sed id maxime provmque modi beatae sed consectetur quisquam ullam dicta dolorum maiores</Typography>
                </Grid>
                <Grid
                    item
                    xs={12}
                    sm={6}
                    md={4}
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        textAlign: "center",
                        // alignItems: "center",
                    }}
                >
                    <img src="images/Group 1550.png
                    " alt="Image" style={imageStyle} />
                    <Typography variant="h5" color="initial" sx={{ color: '#FFFFFF', marginTop: "10px" }}>
                        Get notice by right customer
                    </Typography>
                    <Typography sx={{ color: '#FFFFFF', paddingX: "47px", marginTop: "10px" }} >Lorem ipsum dolor sit amet consectetur adipisicings ducimus dolorum, sed id maxime provmque modi beatae sed consectetur quisquam ullam dicta dolorum maiores</Typography>
                </Grid>
            </Grid>
        </Box >

    </Container>
}
