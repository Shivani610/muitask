import React from 'react'
import Home from './Home'
import Pra from './Pra'
import CardCare from './CardCare'
import Practise from './Practise'

export default function App() {
  return (
    <div>
      <Pra />
      <Home />
      <CardCare />
      {/* <Practise /> */}

    </div>
  )
}
